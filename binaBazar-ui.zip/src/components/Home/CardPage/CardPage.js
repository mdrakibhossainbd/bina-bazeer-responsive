import React from 'react';

const CardPage = () => {
    return (
        <div>
            <div className="container">
           <h1>card page</h1>
            </div>
        </div>
    );
};

export default CardPage;