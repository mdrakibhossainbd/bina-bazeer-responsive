
const MenuBarData= [
    
    {
        name: 'কৃষি বাজার',
        drawer: [
            {
                name: 'action',
                link: "#" 
            },
            {
                name: 'another action',
                link: "#" 
            },
            {
                name: 'seperate action',
                link: "/customerDashboard" 
            },
            {
                name: 'something',
                link: "#" 
            }
        ]
    },
    {
        name: 'মুদি বাজার',
        link: "/"
    },
    {
        name: 'ফ্যাশন বাজার',
        
        drawer: [
            {
                name: 'action',
                link: "#" 
            },
            {
                name: 'another action',
                link: "#" 
            },
            {
                name: 'seperate action',
                link: "/customerDashboard" 
            },
            {
                name: 'something',
                link: "#" 
            }
        ]
    },
    {
        name: 'পুস্টি বাজার ',
        link: "/"
    },
    {
        name: 'কাপড় বাজার ',
        link: "/"
    },
    {
        name: 'নির্মান বাজার',
        drawer: [
            {
                name: 'action',
                link: "#" 
            },
            {
                name: 'another action',
                link: "#" 
            },
            {
                name: 'seperate action',
                link: "/customerDashboard" 
            },
            {
                name: 'something',
                link: "#" 
            }
        ]
        
    },
    
    {
        name: 'মেডিসিন বাজার',
        link: "/"
       
    },
    {
        name: 'বই বাজার',
        link: "/"
       
    },
   

]

export default MenuBarData
