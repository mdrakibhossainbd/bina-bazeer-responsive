import React from 'react';
import '../../MainCSS/MainCSS.css';
import slider1 from '../../../img/slide1.jpg';

const Slider = () => {
    return (
        <div className="slider-size">

            <img src={slider1} alt="" />
        </div>
    );
};

export default Slider;