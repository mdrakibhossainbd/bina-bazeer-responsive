var bazarInfo = [
    {
        id: '1',
        name: 'krishiBazar',
        list: [

            {
                id: "1",
                name: 'Mutton',
                img: "https://i.ibb.co/TP70Rxb/unnamed.jpg",
                price: "380",
                pastPrice: "450",
            },
            {
                id: "2",
                name: 'Fish',
                img: "https://i.ibb.co/X4Fbf77/depositphotos-13189440-stock-photo-popular-rohu-or-rohit-fish.jpg",
                price: "350",
                pastPrice: "450",
            },
            {
                id: "3",
                name: 'Banana',
                img: "https://i.ibb.co/db3wHqr/42-E9as7-Na-Ta-Ai4-A6-Jcu-Fw-G-1200-80.jpg",
                price: "30",
                pastPrice: "50",
            },
            {
                id: "4",
                name: 'Guava',
                img: "https://i.ibb.co/mX5dGS2/Screenshot-10.png",
                price: "40",
                pastPrice: "45",
            },
            {
                id: "5",
                name: 'Lal Shak',
                img: "https://i.ibb.co/yh2kYLm/download.jpg",
                price: "5",
                pastPrice: "8",
            },
            {
                id: "6",
                name: 'Tomato',
                img: "https://i.ibb.co/RzKdDRG/Tomato-je.jpg",
                price: "80",
                pastPrice: "100",
            },
            {
                id: "7",
                name: 'Chicken',
                img: "https://i.ibb.co/fXBZ3r7/raw-chicken-meat-1203-6759.jpg",
                price: "120",
                pastPrice: "150",
            },
            {
                id: "8",
                name: 'Mutton',
                img: "https://i.ibb.co/TP70Rxb/unnamed.jpg",
                price: "380",
                pastPrice: "450",
            },
        ]
    },

    {
        id: '2',
        name: 'MudiBazar',
        list: [

            {
                id: "1",
                name: 'Rice',
                img: "https://i.ibb.co/XzxDK7w/Screenshot-2.png",
                price: "2350",
                pastPrice: "2500",
            },
            {
                id: "2",
                name: 'Oil',
                img: "https://i.ibb.co/wsRGB9J/Screenshot-3.png",
                price: "110",
                pastPrice: "130",
            },
            {
                id: "3",
                name: 'Salt',
                img: "https://i.ibb.co/2df43pW/Screenshot-4.png",
                price: "45",
                pastPrice: "50",
            },
            {
                id: "4",
                name: 'Moida',
                img: "https://i.ibb.co/DzX3My7/Screenshot-5.png",
                price: "40",
                pastPrice: "45",
            },
            {
                id: "5",
                name: 'Rice',
                img: "https://i.ibb.co/XzxDK7w/Screenshot-2.png",
                price: "2350",
                pastPrice: "2500",
            },
            {
                id: "6",
                name: 'Oil',
                img: "https://i.ibb.co/wsRGB9J/Screenshot-3.png",
                price: "110",
                pastPrice: "130",
            },
            {
                id: "7",
                name: 'Salt',
                img: "https://i.ibb.co/2df43pW/Screenshot-4.png",
                price: "45",
                pastPrice: "50",
            },
            {
                id: "8",
                name: 'Moida',
                img: "https://i.ibb.co/DzX3My7/Screenshot-5.png",
                price: "40",
                pastPrice: "45",
            },

        ]
    },

    {
        id: '3',
        name: 'FashionBazar',
        list: [

            {
                id: "1",
                name: 'SHIRT',
                img: "https://i.ibb.co/Rhff2Bt/Screenshot-6.png",
                price: "550",
                pastPrice: "600",
            },
            {
                id: "2",
                name: 'SUNGLASS',
                img: "https://i.ibb.co/DrvwXLX/Screenshot-7.png",
                price: "110",
                pastPrice: "130",
            },
            {
                id: "3",
                name: 'BLAZER',
                img: " https://i.ibb.co/gFHGF8m/Screenshot-8.png",
                price: "2000",
                pastPrice: "2200",
            },
            {
                id: "4",
                name: 'JACKET',
                img: "https://i.ibb.co/m9m1TyR/Screenshot-9.png",
                price: "1500",
                pastPrice: "2000",
            },
            {
                id: "5",
                name: 'WINTER CLOTH',
                img: "https://i.ibb.co/G5tFxJ5/Screenshot-10.png",
                price: "2350",
                pastPrice: "2500",
            },
            {
                id: "6",
                name: 'BAG',
                img: "https://i.ibb.co/vBK8fMb/Screenshot-11.png",
                price: "150",
                pastPrice: "200",
            },
            {
                id: "7",
                name: 'SUNGLASS',
                img: "https://i.ibb.co/QjSbftL/Screenshot-13.png",
                price: "45",
                pastPrice: "50",
            },
            {
                id: "8",
                name: 'KURTI',
                img: "https://i.ibb.co/MntsLtR/Screenshot-14.png",
                price: "350",
                pastPrice: "400",
            },

        ]
    },

];

export default bazarInfo;