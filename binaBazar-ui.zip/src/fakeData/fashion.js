var fashions = [
    {
        id: "1",
        name: 'SHIRT',
        img: "https://i.ibb.co/Rhff2Bt/Screenshot-6.png",
        price: "550",
        pastPrice: "600",
    },
    {
        id: "2",
        name: 'SUNGLASS',
        img: "https://i.ibb.co/DrvwXLX/Screenshot-7.png",
        price: "110",
        pastPrice: "130",
    },
    {
        id: "3",
        name: 'BLAZER',
        img: " https://i.ibb.co/gFHGF8m/Screenshot-8.png",
        price: "2000",
        pastPrice: "2200",
    },
    {
        id: "4",
        name: 'JACKET',
        img: "https://i.ibb.co/m9m1TyR/Screenshot-9.png",
        price: "1500",
        pastPrice: "2000",
    },
    {
        id: "5",
        name: 'WINTER CLOTH',
        img: "https://i.ibb.co/G5tFxJ5/Screenshot-10.png",
        price: "2350",
        pastPrice: "2500",
    },
    {
        id: "6",
        name: 'BAG',
        img: "https://i.ibb.co/vBK8fMb/Screenshot-11.png",
        price: "150",
        pastPrice: "200",
    },
    {
        id: "7",
        name: 'SUNGLASS',
        img: "https://i.ibb.co/QjSbftL/Screenshot-13.png",
        price: "45",
        pastPrice: "50",
    },
    {
        id: "8",
        name: 'KURTI',
        img: "https://i.ibb.co/MntsLtR/Screenshot-14.png",
        price: "350",
        pastPrice: "400",
    },
]

export default fashions;