import fashions from './fashion';
import krishi from './krishi';
import mudi from './mudi';

const fakeData = [...krishi, ...mudi, ...fashions];




export default fakeData;