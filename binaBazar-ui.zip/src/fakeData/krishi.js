var krishi = [

    {
        id: "1",
        name: 'Mutton',
        img: "https://i.ibb.co/TP70Rxb/unnamed.jpg",
        price: "380",
        pastPrice: "450",
    },
    {
        id: "2",
        name: 'Fish',
        img: "https://i.ibb.co/X4Fbf77/depositphotos-13189440-stock-photo-popular-rohu-or-rohit-fish.jpg",
        price: "350",
        pastPrice: "450",
    },
    {
        id: "3",
        name: 'Banana',
        img: "https://i.ibb.co/db3wHqr/42-E9as7-Na-Ta-Ai4-A6-Jcu-Fw-G-1200-80.jpg",
        price: "30",
        pastPrice: "50",
    },
    {
        id: "4",
        name: 'Guava',
        img: "https://i.ibb.co/mX5dGS2/Screenshot-10.png",
        price: "40",
        pastPrice: "45",
    },
    {
        id: "5",
        name: 'Lal Shak',
        img: "https://i.ibb.co/yh2kYLm/download.jpg",
        price: "5",
        pastPrice: "8",
    },
    {
        id: "6",
        name: 'Tomato',
        img: "https://i.ibb.co/RzKdDRG/Tomato-je.jpg",
        price: "80",
        pastPrice: "100",
    },
    {
        id: "7",
        name: 'Chicken',
        img: "https://i.ibb.co/fXBZ3r7/raw-chicken-meat-1203-6759.jpg",
        price: "120",
        pastPrice: "150",
    },
    {
        id: "8",
        name: 'Mutton',
        img: "https://i.ibb.co/TP70Rxb/unnamed.jpg",
        price: "380",
        pastPrice: "450",
    },
];

export default krishi;