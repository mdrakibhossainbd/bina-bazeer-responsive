var mudi = [
    {
        id: "1",
        name: 'Rice',
        img: "https://i.ibb.co/XzxDK7w/Screenshot-2.png",
        price: "2350",
        pastPrice: "2500",
    },
    {
        id: "2",
        name: 'Oil',
        img: "https://i.ibb.co/wsRGB9J/Screenshot-3.png",
        price: "110",
        pastPrice: "130",
    },
    {
        id: "3",
        name: 'Salt',
        img: "https://i.ibb.co/2df43pW/Screenshot-4.png",
        price: "45",
        pastPrice: "50",
    },
    {
        id: "4",
        name: 'Moida',
        img: "https://i.ibb.co/DzX3My7/Screenshot-5.png",
        price: "40",
        pastPrice: "45",
    },
    {
        id: "5",
        name: 'Rice',
        img: "https://i.ibb.co/XzxDK7w/Screenshot-2.png",
        price: "2350",
        pastPrice: "2500",
    },
    {
        id: "6",
        name: 'Oil',
        img: "https://i.ibb.co/wsRGB9J/Screenshot-3.png",
        price: "110",
        pastPrice: "130",
    },
    {
        id: "7",
        name: 'Salt',
        img: "https://i.ibb.co/2df43pW/Screenshot-4.png",
        price: "45",
        pastPrice: "50",
    },
    {
        id: "8",
        name: 'Moida',
        img: "https://i.ibb.co/DzX3My7/Screenshot-5.png",
        price: "40",
        pastPrice: "45",
    },

]

export default mudi;